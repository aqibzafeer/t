// app/layout.js
import "./globals.css";
import { Analytics } from "@vercel/analytics/next";
import { AuthProvider } from "@/app/context/AuthContext";

export const metadata = {
  title: "Ambala",
  description: "Ambala Tea storefront built with Next.js",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <AuthProvider>
          <Analytics />
          <main className="min-h-screen">{children}</main>
        </AuthProvider>
      </body>
    </html>
  );
}
